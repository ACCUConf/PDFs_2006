// Copyright 2006 (C) Bronislaw Kozicki

// Use, modification, and distribution is subject to the Boost Software
// License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <cstdio>
#include <cstring>

#include "brok_mpl.hpp"

namespace brok
{
  namespace detail
  {
    typedef void* (*cast_get)(char*);

    template <typename A> 
    union cast
    {
      A a;
      char p[sizeof(A)];

      template <int Size>
      static void init(char (&p)[Size])
      {
        mpl::static_assert<Size >= sizeof(A)>();
        memset(p, 0, Size);
      }

      static void *typeless_get(char *p)
      {
        return &((reinterpret_cast<cast<A> *> (p))->a);
      }

      static A *get(char *p)
      {
        return reinterpret_cast<A *>(typeless_get(p));
      }
    };

    typedef void (*trampoline_exec)(char*, char*);

    template <typename A, typename F>
    class trampoline
    {
      template <typename V>
      static void jump(V& f)
      {
        f();
      }

      template <typename V>
      static void jump(V* f)
      {
        (*f)();
      }

      template <typename V>
      static void jump(V& f, A& a)
      {
        f(a);
      }

      template <typename V>
      static void jump(V* f, A& a)
      {
        (*f)(a);
      }

    public:
      static void exec1(char* fp, char *p)
      {
        F* f = cast<F>::get(fp);
        A* a = cast<A>::get(p);
        jump(*f, *a);
      }

      static void exec0(char* fp, char *)
      {
        F* f = cast<F>::get(fp);
        jump(*f);
      }
    };
  } // namespace detail
    
  template <typename A> class function1;
  
  class function
  {
    static void noop(char*, char *) {}
    struct nil{};
 
    mutable char f_[sizeof(void*)];
    mutable char a_[sizeof(void*)];
    detail::trampoline_exec c_;
    detail::cast_get g_;
    
  public:
    function() : c_(&noop)
    {
      detail::cast<nil>::init(f_);
      detail::cast<nil>::init(a_);
    }
    
    template <typename F>
    explicit function(F f)
    {
      detail::cast<typename mpl::remove_ref<F>::type>::init(f_);
      detail::cast<nil>::init(a_);
      *(detail::cast<typename mpl::remove_ref<F>::type>::get(f_)) = f;

      c_ = &(detail::trampoline<
        nil ,
        typename mpl::remove_ref<F>::type
        >::exec0);
      g_ = &(detail::cast<nil>::typeless_get);
    }

    template <typename A, typename F>
    function(A a, F f)
    {
      detail::cast<typename mpl::remove_ref<F>::type>::init(f_);
      detail::cast<typename mpl::remove_ref<A>::type>::init(a_);
      *(detail::cast<typename mpl::remove_ref<F>::type>::get(f_)) = f;
      *(detail::cast<typename mpl::remove_ref<A>::type>::get(a_)) = a;

      c_ = &(detail::trampoline<
        typename mpl::remove_ref<A>::type ,
        typename mpl::remove_ref<F>::type
        >::exec1);
      g_ = &(detail::cast<typename mpl::remove_ref<A>::type>::typeless_get);
    }

    void reset()
    {
      c_ = &noop;
    }
    
    bool empty() const
    {
      return c_ == &noop;
    }

#if defined(_MSC_VER) && !defined(__COMO__)
# pragma message("Due to compiler deficiency, you must enable symbols in order for type() to work")
#endif

    template <typename A>
    bool type() const
    {
      detail::cast_get g = &(detail::cast<typename mpl::remove_ref<A>::type>::typeless_get);
      return (g == g_);
    }

    template <typename A>
    typename mpl::remove_ref<A>::type& get()
    {
      return *reinterpret_cast<typename mpl::remove_ref<A>::type *> (g_(&a_[0]));
    }

    template <typename A>
    const typename mpl::remove_ref<A>::type& get() const
    {
      return *reinterpret_cast<typename mpl::remove_ref<A>::type *> (g_(&a_[0]));
    }

    void operator()() const
    {
      (*c_)(&f_[0], &a_[0]);
    }
  }; // class function

#ifdef __GNUC__
  namespace detail
  { // workaround for GCC linker deficiency
    template void* cast<function::nil>::typeless_get(char*);
  }
#endif
} // namespace brok

struct Demo
{
  const char* p1;
  void operator()(const char *p2)
  {
    printf("demo(\"%s\", \"%s\")\n", p1, p2);
  }
};


void foo(int i)
{
  printf("foo(%d)\n", i);
}

void bar(const char* sz)
{
  printf("bar(\"%s\")\n", sz);
}

struct Boo
{
  void operator()()
  {
    printf("boo()\n");
  }
};

int main()
{
  Demo demo = {"Hello"};
  brok::function f("world", &demo);
  f();
  
  f.get<const char*>() = "there!";
  f();

  f = brok::function (42, foo);
  f();

  f = brok::function("Hello world", &bar);
  f();

  f = brok::function(Boo());
  f();
}

