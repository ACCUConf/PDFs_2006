// Following code is placed in public domain

namespace brok
{
  namespace mpl
  {
    // poorman's static assert
    template <bool> struct static_assert;
    template <> struct static_assert<true> {};

    // type trait - remove reference
    template <typename T> struct remove_ref
    {
      typedef T type;
    };

    template <typename T> struct remove_ref<T&>
    {
      typedef T type;
    };

    // type selection (if)
    template <bool If, typename A, typename B>
    struct if_;

    template <typename A, typename B>
    struct if_<true, A, B>
    {
      typedef A type;
    };

    template <typename A, typename B>
    struct if_<false, A, B>
    {
      typedef B type;
    };

    // get max sizeof
    template <typename A, typename B>
    struct max
    {
      typedef typename if_<(sizeof(A) > sizeof(B)), A, B>::type type;
      enum {size = sizeof(type)};
    };

    // poorman's type traits - for real thing see boost::type_traits
    template <typename A> struct is_ptr
    {
      enum {value = false};
    };
    
    template <typename A> struct is_ptr<A*>
    {
      enum {value = true};
    };

    template <typename A> struct is_mem_fun_ptr
    {
      enum {value = false};
    };
    
    template <typename R, typename T> struct is_mem_fun_ptr<R (T::*)()>
    {
      enum {value = true};
    };

    template <typename R, typename T> struct is_mem_fun_ptr<R (T::*)() const>
    {
      enum {value = true};
    };
  } // namespace mpl
} // namespace brok
