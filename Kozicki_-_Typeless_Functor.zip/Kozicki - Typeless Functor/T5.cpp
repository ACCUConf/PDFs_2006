// Copyright 2006 (C) Bronislaw Kozicki

// Use, modification, and distribution is subject to the Boost Software
// License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <cstdio>

#include "brok_mpl.hpp"

namespace brok
{
  class function
  {
    typedef void (*t0_f)(char*, char*);

    template <typename A, typename F>
    class trampoline
    {
      static void exec(char* p, char *a1)
      {
        mpl::static_assert<sizeof(char*) >= sizeof(F)>();
        mpl::static_assert<sizeof(char*) >= sizeof(A)>();
        F* f = (F*) &p;
        A* a = (A*) &a1;
        (**f)(*a);
      }

    public:
      static void pack(t0_f* c, F f, char** p, A a, char** a1)
      {
        *p = *((char**) &f);
        *a1 = *((char**) &a);
        *c = &exec;
      }
    };

    char* f_;
    char* a_;
    t0_f c_;
  
  public:
    template <typename A, typename F>
    function(A a, F f)
    {
      trampoline<A, F>::pack(&c_, f, &f_, a, &a_);
    }

    void reset()
    {
      c_ = 0;
    }

    void operator()() const
    {
      if (c_)
        (*c_)(f_, a_);
    }
  };
  
  class scope_guard
  {
    function f_;

    // non-assignable
    scope_guard& operator=(const scope_guard&);

  public:  
    explicit scope_guard(function f) : f_(f)
    {}

    scope_guard(scope_guard& o)
      : f_(o.release())
    {}
    
  // poorman's move semantics
  private: 
    struct ref{ref(scope_guard* p) : p(p) {} scope_guard* p;};

  public:
    operator ref()
    {
      return ref(this);
    }

    scope_guard(ref rhs)
      : f_(rhs.p->release())
    {}

    function release()
    {
      function r = f_;
      f_.reset();
      return r;
    }

    ~scope_guard()
    {
      f_();
    }
  };
} // namespace brok

brok::scope_guard source();

void f(int i)
{
  printf("f(%d)\n", i);
}


int main()
{
  brok::scope_guard s = source();
  brok::scope_guard s1 = s;
  const brok::scope_guard s3 = s1;
  // const brok::scope_guard s4 = s3; // ERROR - attempt to move from const
  
  brok::scope_guard s5(brok::function(44, &f));
  brok::scope_guard s6(brok::function(42, &f));
  s5.release();
  
  brok::scope_guard s7(s5.release());
}

// might be another TU
struct A
{
  A() {puts("A::A");}
  ~A() {puts("A::~A");}
};

struct Delete
{
  template <typename A> void operator()(A* a)
  {
    delete a;
  }
} delete_;


brok::scope_guard source()
{
  return brok::scope_guard(brok::function(new A(), &delete_));
}

