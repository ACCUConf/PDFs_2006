// Copyright 2006 (C) Bronislaw Kozicki

// Use, modification, and distribution is subject to the Boost Software
// License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <cstdio>

#include "brok_mpl.hpp"

namespace brok
{
  template<typename A>
  class function1
  {
    typedef void (*t1_f)(char*, A);

    template <typename F>
    class trampoline
    {
      static void exec(char* p, A a)
      {
        mpl::static_assert<sizeof(char*) >= sizeof(F)>();
        F* f = (F*) &p;
        (**f)(a);
      }

    public:
      static void pack(t1_f* c, F f, char** p)
      {
        *p = *((char**) &f);
        *c = &exec;
      }
    };

    char* f_;
    A a_;
    t1_f c_;
  
  public:
    function1() : f_(0), a_(A()), c_(0)
    {}
    
    template <typename F>
    function1(F f) : a_(A())
    {
      trampoline<F>::pack(&c_, f, &f_);
    }

    template <typename F>
    function1(A a, F f) : a_(a)
    {
      trampoline<F>::pack(&c_, f, &f_);
    }

    void reset()
    {
      c_ = 0;
    }
    
    bool empty() const
    {
      return c_ == 0;
    }
    
    A& get()
    {
      return a_;
    }

    const A& get() const
    {
      return a_;
    }

    void operator()() const
    {
      (*c_)(f_, a_);
    }
  };
} // namespace brok

void bar(const char* sz)
{
  printf("bar(\"%s\")\n", sz);
}

struct Boo
{
  void operator()(const char* sz)
  {
    printf("boo(\"%s\")\n", sz);
  }
} boo;

int main()
{
  brok::function1<const char*> f1("Hello", &bar);
  f1();

  f1 = brok::function1<const char*>(&boo);
  f1();
  
  f1.get() = "world!";
  f1();
}
