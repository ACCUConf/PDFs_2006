// Copyright 2006 (C) Bronislaw Kozicki

// Use, modification, and distribution is subject to the Boost Software
// License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <cstdio>

#include "brok_mpl.hpp"

namespace brok
{
  template <typename A> class function1;
  
  class function
  {
    typedef void (*t0_f)(char*, char*);
    template <typename A> friend class function1;

    template <typename A, typename F>
    class trampoline
    {
      union cast
      {
        char* p;
        A a;
      };

      static void exec(char* p, char *a)
      {
        mpl::static_assert<sizeof(char*) >= sizeof(F)>();
        mpl::static_assert<sizeof(char*) >= sizeof(A)>();
        cast c = {a};
        F* f = (F*) &p;
        (**f)(*c.a);
      }

    public:
      static void pack(t0_f* c, F f, char** p, A a, char** a1)
      {
        *p = *((char**) &f);
        cast c1;
        c1.a = a;
        *a1 = c1.p;
        *c = &exec;
      }
    };

    char* f_;
    char* a_;
    t0_f c_;
  
  public:
    function() : f_(0), a_(0), c_(0)
    {}
    
    template <typename A, typename F>
    function(A a, F f)
    {
      trampoline<A, F>::pack(&c_, f, &f_, a, &a_);
    }

    void reset()
    {
      c_ = 0;
    }
    
    bool empty() const
    {
      return c_ == 0;
    }

    void operator()() const
    {
      (*c_)(f_, a_);
    }
  };

  template<typename A>
  class function1
  {
    union cast
    {
      char* p;
      A a;
    };

    typedef void (*t1_f)(char*, char*);

    template <typename F>
    class trampoline
    {
      static void exec(char* p, char* a)
      {
        mpl::static_assert<sizeof(char*) >= sizeof(F)>();
        mpl::static_assert<sizeof(char*) >= sizeof(A)>();
        cast c = {a};
        F* f = (F*) &p;
        (**f)(c.a);
      }

    public:
      static void pack(t1_f* c, F f, char** p)
      {
        *p = *((char**) &f);
        *c = &exec;
      }
    };

    char* f_;
    cast a_;
    t1_f c_;
  
  public:
    function1() : f_(0), c_(0)
    {}
    
    template <typename F>
    function1(F f)
    {
      trampoline<F>::pack(&c_, f, &f_);
    }

    template <typename F>
    function1(A a, F f)
    {
      trampoline<F>::pack(&c_, f, &f_);
      a_.a = a;
    }

    void reset()
    {
      c_ = 0;
    }
    
    bool empty() const
    {
      return c_ == 0;
    }
    
    A& get()
    {
      return a_.a;
    }

    const A& get() const
    {
      return a_.a;
    }
    
    operator function () const
    {
      function r;
      r.f_ = f_;
      r.a_ = a_.p;
      r.c_ = c_;
      return r;
    }

    void operator()() const
    {
      (*c_)(f_, a_.p);
    }
  };
} // namespace brok

void foo(int i)
{
  printf("foo(%d)\n", i);
}

void bar(const char* sz)
{
  printf("bar(\"%s\")\n", sz);
}

struct Boo
{
  void operator()(const char* sz)
  {
    printf("boo(\"%s\")\n", sz);
  }
} boo;

void go(const brok::function&);

int main()
{
  brok::function1<const char*> f1("Hello", &bar);
  f1();

  f1 = brok::function1<const char*>(&boo);
  f1.get() = "world!";
  go(f1);
  
  brok::function1<int> f2(&foo);
  f2.get() = 42;
  go(f2);
}

void go(const brok::function& f)
{
  f();
}
