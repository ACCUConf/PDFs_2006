// Copyright 2006 (C) Bronislaw Kozicki

// Use, modification, and distribution is subject to the Boost Software
// License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <cstdio>
#include <memory>

#include "brok_mpl.hpp"

namespace brok
{
  class function
  {
    typedef void (*t0_f)(char*, char*);

    template <typename A, typename F>
    class trampoline
    {
      static void exec(char* p, char *a1)
      {
        mpl::static_assert<sizeof(char*) >= sizeof(F)>();
        mpl::static_assert<sizeof(char*) >= sizeof(A)>();
        F* f = (F*) &p;
        A* a = (A*) &a1;
        (**f)(*a);
      }

    public:
      static void pack(t0_f* c, F f, char** p, A a, char** a1)
      {
        *p = *((char**) &f);
        *a1 = *((char**) &a);
        *c = &exec;
      }
    };

    char* f_;
    char* a_;
    t0_f c_;
  
  public:
    function() : f_(0), a_(0), c_(0)
    {}
    
    template <typename A, typename F>
    function(A a, F f)
    {
      trampoline<A, F>::pack(&c_, f, &f_, a, &a_);
    }

    void reset()
    {
      c_ = 0;
    }
    
    bool empty() const
    {
      return c_ == 0;
    }

    void operator()() const
    {
      (*c_)(f_, a_);
    }
  };
  
  class scope_guard
  {
    function f_;
    std::auto_ptr<scope_guard> o_;
    
    // non-assignable
    scope_guard& operator=(const scope_guard&);

    scope_guard* release_o()
    {
      return o_.release();
    }
    
    function release_f()
    {
      function r = f_;
      f_.reset();
      return r;
    }

  public:  
    explicit scope_guard(function f)
      : f_(f)
    {}

    // non-const lvalue
    scope_guard(scope_guard& o)
      : f_(o.release_f()), o_(o.release_o())
    {}

  // poorman's move semantics
  private:
    struct ref{ref(scope_guard* p) : p(p) {} scope_guard* p;};

  public:
    operator ref()
    {
      return ref(this);
    }

    scope_guard(ref r)
        : f_(r.p->release_f()), o_(r.p->release_o())
    {}

    function release()
    {
      if (o_.get())
        o_->release();
      o_.reset();
      return release_f();
    }

    scope_guard& attach(ref r)
    {
      if (o_.get())
        o_->attach(r);
      else
        o_.reset(new scope_guard(*r.p));
      return *this;
    }
    
    ~scope_guard()
    {
      o_.reset();
      if (!f_.empty())
        f_();
    }
  };
} // namespace brok

brok::scope_guard source();
void sink(brok::scope_guard);

void f(int i)
{
  printf("f(%d)\n", i);
}

int main()
{
  brok::scope_guard s = source();
  s.attach(brok::scope_guard(brok::function(42, &f)));
  sink(s);
}

// another TU or dynamic library
struct A
{
  int i;
  A(int i) : i(i) {printf("A::A(%d)\n", i);}
  ~A() {printf("A::~A(%d)\n", i);}
};

struct Delete
{
  template <typename A> void operator()(A* a)
  {
    delete a;
  }
} delete_;

brok::scope_guard source()
{
  return brok::scope_guard(brok::function(new A(1), &delete_))
    .attach(brok::scope_guard(brok::function(new A(2), &delete_)))
    .attach(brok::scope_guard(brok::function(new A(3), &delete_)));
}

void sink(brok::scope_guard s)
{
  s.attach(brok::scope_guard(brok::function(new A(4), &delete_)));
  s.attach(brok::scope_guard(brok::function(new A(5), &delete_)));
  s.attach(brok::scope_guard(brok::function(new A(6), &delete_)));
}

