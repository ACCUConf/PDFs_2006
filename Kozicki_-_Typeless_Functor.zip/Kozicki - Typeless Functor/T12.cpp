// Copyright 2006 (C) Bronislaw Kozicki

// Use, modification, and distribution is subject to the Boost Software
// License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <cstdio>
#include <cstring>

#include "brok_mpl.hpp"

namespace brok
{
  namespace detail
  {
    typedef void* (*cast_get)(char*);

    template <typename A> 
    union cast
    {
      A a;
      char p[sizeof(A)];

      template <int Size>
      static void init(char (&p)[Size])
      {
        mpl::static_assert<Size >= sizeof(A)>();
        memset(p, 0, sizeof(A));
      }

      static void *typeless_get(char *p)
      {
        return &((reinterpret_cast<cast<A> *> (p))->a);
      }

      static A *get(char *p)
      {
        return reinterpret_cast<A *>(typeless_get(p));
      }
    };

    typedef void (*trampoline_exec)(char*, char*);

    template <typename A, typename F>
    class trampoline
    {
      template <typename V>
      static void jump(V& f, A& a)
      {
        f(a);
      }

      template <typename V>
      static void jump(V* f, A& a)
      {
        (*f)(a);
      }

    public:
      static void exec(char* fp, char *p)
      {
        F* f = cast<F>::get(fp);
        A* a = cast<A>::get(p);
        jump(*f, *a);
      }
    };

    template <typename F, typename R>
    class trampoline<R (F::*)(), F>
    {
      template <typename V>
      static void jump(V& f, R (F::*a)())
      {
        (f.*a)();
      }

      template <typename V>
      static void jump(V* f, R (F::*a)())
      {
        (f->*a)();
      }

    public:
      static void exec(char* fp, char *p)
      {
        F* f = cast<F>::get(fp);
        R (F::**a)() = cast<R (F::*)()>::get(p);
        jump(*f, *a);
      }
    };

    template <typename F, typename R>
    class trampoline<R (F::*)() const, F>
    {
      template <typename V>
      static void jump(V& f, R (F::*a)() const)
      {
        (f.*a)();
      }

      template <typename V>
      static void jump(V* f, R (F::*a)() const)
      {
        (f->*a)();
      }

    public:
      static void exec(char* fp, char *p)
      {
        F* f = cast<F>::get(fp);
        R (F::**a)() const = cast<R (F::*)() const>::get(p);
        jump(*f, *a);
      }
    };
  } // namespace detail
    
  template <typename A> class function1;
  
  class function
  {
    mutable char f_[sizeof(void*)];
    mutable char a_[mpl::max<void*, void (function::*)()>::size];
    detail::trampoline_exec c_;
    detail::cast_get g_;
    
  public:
    function() : c_(0)
    {}
    
    template <typename A, typename F>
    function(A a, F f)
    {
      detail::cast<typename mpl::remove_ref<F>::type>::init(f_);
      detail::cast<typename mpl::remove_ref<A>::type>::init(a_);
      *(detail::cast<typename mpl::remove_ref<F>::type>::get(f_)) = f;
      *(detail::cast<typename mpl::remove_ref<A>::type>::get(a_)) = a;

      c_ = &(detail::trampoline<
        typename mpl::remove_ref<A>::type ,
        typename mpl::remove_ref<F>::type
        >::exec);
      g_ = &(detail::cast<typename mpl::remove_ref<A>::type>::typeless_get);
    }

    template <typename R, typename F>
    function(R (F::*a)(), F f)
    {
      detail::cast<typename mpl::remove_ref<F>::type>::init(f_);
      detail::cast<R (F::*)()>::init(a_);
      *(detail::cast<typename mpl::remove_ref<F>::type>::get(f_)) = f;
      *(detail::cast<R (F::*)()>::get(a_)) = a;

      c_ = &(detail::trampoline<
        R (F::*)(),
        typename mpl::remove_ref<F>::type
        >::exec);
      g_ = &(detail::cast<typename mpl::remove_ref<R (F::*)()>::type>::typeless_get);
    }

    void reset()
    {
      c_ = 0;
    }
    
    bool empty() const
    {
      return c_ == 0;
    }

#if defined(_MSC_VER) && !defined(__COMO__)
# pragma message("Due to compiler deficiency, you must enable symbols in order for type() to work")
#endif

    template <typename A>
    bool type() const
    {
      detail::cast_get g = &(detail::cast<typename mpl::remove_ref<A>::type>::typeless_get);
      return (g == g_);
    }

    template <typename A>
    typename mpl::remove_ref<A>::type& get()
    {
      return *reinterpret_cast<typename mpl::remove_ref<A>::type *> (g_(&a_[0]));
    }

    template <typename A>
    const typename mpl::remove_ref<A>::type& get() const
    {
      return *reinterpret_cast<typename mpl::remove_ref<A>::type *> (g_(&a_[0]));
    }

    void operator()() const
    {
      (*c_)(&f_[0], &a_[0]);
    }
  }; // class function
} // namespace brok

struct Demo
{
  const char* p1;
  void operator()(const char *p2)
  {
    printf("demo(\"%s\", \"%s\")\n", p1, p2);
  }
  
  void one()
  {
    printf("one(\"%s\")\n", p1);
  }

  void two() const
  {
    printf("two(\"%s\") const\n", p1);
  }

  void three()
  {
    printf("three(\"%s\")\n", p1);
  }
};

int main()
{
  Demo demo = {"Hello"};
  brok::function f("world", demo);
  f();
  
  f.get<const char*>() = "there!";
  f();
  
  f = brok::function(&Demo::one, demo);
  f();
  
  if (f.type<void (Demo::*)() const>())
  {
    f.get<void (Demo::*)() const>() = &Demo::two;
    f();
  }
  
  if (f.type<void (Demo::*)()>())
  {
    f.get<void (Demo::*)()>() = &Demo::three;
    f();
  }

  f = brok::function(&Demo::two, demo);
  f();

//  f = brok::function(&Demo::one, &demo);
  f();
}

