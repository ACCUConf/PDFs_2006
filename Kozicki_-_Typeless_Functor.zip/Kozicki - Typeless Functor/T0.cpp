// Author: Bronislaw Kozicki mailto:brok@spamcop.net
// The code is placed in public domain by author

#include <cstdio>

namespace brok
{
  typedef void (*t0_f)(char*);

  template <typename F>
  static void exec(char* p)
  {
    F* f = (F*) &p;
    (**f)();
  }

  template <typename F>
  static void pack(F f, t0_f* c, char** p)
  {
    *c = &exec<F>;
    *p = *((char **) &f);
  }
} // namespace brok

void foo()
{
  puts("foo;");
}

struct Boo
{
  void operator()()
  {
    puts("boo;");
  }
} boo;

int main()
{
  char* p;
  brok::t0_f c;
  
  brok::pack<void(*)()>(&foo, &c, &p);
  (*c)(p);

  brok::pack<Boo*>(&boo, &c, &p);
  (*c)(p);
}
