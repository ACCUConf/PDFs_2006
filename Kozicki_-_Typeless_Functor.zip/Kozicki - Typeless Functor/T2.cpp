// Copyright 2006 (C) Bronislaw Kozicki

// Use, modification, and distribution is subject to the Boost Software
// License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <cstdio>

#include "brok_mpl.hpp"

namespace brok
{
  class function
  {
    typedef void (*t0_f)(char*, char*);

    template <typename A, typename F>
    class trampoline
    {
      static void exec(char* p, char *a1)
      {
        mpl::static_assert<sizeof(char*) >= sizeof(F)>();
        mpl::static_assert<sizeof(char*) >= sizeof(A)>();
        F* f = (F*) &p;
        A* a = (A*) &a1;
        (**f)(*a);
      }

    public:
      static void pack(t0_f* c, F f, char** p, A a, char** a1)
      {
        *p = *((char**) &f);
        *a1 = *((char**) &a);
        *c = &exec;
      }
    };

    char* f_;
    char* a_;
    t0_f c_;
  
  public:
    template <typename A, typename F>
    function(A a, F f)
    {
      trampoline<A, F>::pack(&c_, f, &f_, a, &a_);
    }
    
    void operator()() const
    {
      (*c_)(f_, a_);
    }
  };
} // namespace brok

void foo(int i)
{
  printf("foo(%d)\n", i);
}

void bar(const char* sz)
{
  printf("bar(\"%s\")\n", sz);
}

struct Boo
{
  void operator()(const char* sz)
  {
    printf("boo(\"%s\")\n", sz);
  }
} boo;

int main()
{
  brok::function f1(42, &foo);
  f1();

  f1 = brok::function("Hello", &bar);
  f1();

  f1 = brok::function("world", &boo);
  f1();
}
