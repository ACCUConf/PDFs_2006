// Author: Bronislaw Kozicki mailto:brok@spamcop.net
// The code is placed in public domain by author

#include <cstdio>
#include "brok_mpl.hpp"

namespace brok
{
  class function
  {
    typedef void (*t0_f)(char*);

    template <typename F>
    class trampoline
    {
      static void exec(char* p)
      {
        mpl::static_assert<sizeof(char*) >= sizeof(F)>();
        F* f = (F*) &p;
        (**f)();
      }

    public:
      static void pack(F f, t0_f* c, char** p)
      {
        *p = *((char **) &f);
        *c = &exec;
      }
    };

    char* p_;
    t0_f c_;
  
  public:
    template <typename F>
    function(F f)
    {
      trampoline<F>::pack(f, &c_, &p_);
    }
    
    void operator()() const
    {
      (*c_)(p_);
    }
  };
} // namespace brok

void foo()
{
  puts("foo;");
}

int bar()
{
  puts("bar;");
  return 0;
}

struct Boo
{
  void operator()()
  {
    puts("boo;");
  }
} boo;

int main()
{
  brok::function f1(&foo);
  f1();

  f1 = brok::function(&bar);
  f1();

  f1 = brok::function(&boo);
  f1();
}
