// Copyright 2006 (C) Bronislaw Kozicki

// Use, modification, and distribution is subject to the Boost Software
// License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <cstdio>

#include "brok_mpl.hpp"

namespace brok
{
  namespace detail
  {
    typedef void* (*cast_get)(char*);

    template <typename A> 
    union cast
    {
      A a;
      char p[sizeof(A)];

      static void *get(char *p)
      {
        return &((reinterpret_cast<cast<A> *> (p))->a);
      }
    };

    typedef void (*trampoline_exec)(char*, char*);
    
    template <typename A, typename F>
    class trampoline
    {
      template <typename V>
      static void jump(V& f, A& a)
      {
        f(a);
      }

      template <typename V>
      static void jump(V* f, A& a)
      {
        (*f)(a);
      }

      static void exec(char* fp, char *p)
      {
        A* a = reinterpret_cast<A *>(cast<A>::get(p));
        F* f = reinterpret_cast<F *>(cast<F>::get(fp));
        jump(*f, *a);
      }

    public:
      template <int Size1, int Size2>
      static void pack(trampoline_exec* c, F f, char (&fp)[Size1], A a, char (&p)[Size2])
      {
        mpl::static_assert<Size1 >= sizeof(F)>();
        mpl::static_assert<Size2 >= sizeof(A)>();
        *(reinterpret_cast<F *>(cast<F>::get(fp))) = f;
        *(reinterpret_cast<A *>(cast<A>::get(p))) = a;
        *c = &exec;
      }
    };
  } // namespace detail
    
  template <typename A> class function1;
  
  class function
  {
    template <typename A> friend class function1;

    mutable char f_[sizeof(void*)];
    mutable char a_[sizeof(void*)];
    detail::trampoline_exec c_;
    detail::cast_get g_;
    
  public:
    function() : c_(0)
    {}
    
    template <typename A, typename F>
    function(A a, F f)
    {
      detail::trampoline
      <
        typename mpl::remove_ref<A>::type, 
        typename mpl::remove_ref<F>::type
      >::pack(&c_, f, f_, a, a_);

      g_ = &(detail::cast<typename mpl::remove_ref<A>::type>::get);
    }

    void reset()
    {
      c_ = 0;
    }
    
    bool empty() const
    {
      return c_ == 0;
    }

#if defined(_MSC_VER) && !defined(__COMO__)
# pragma message("Due to compiler deficiency, you must enable symbols in order for type() to work")
#endif

    template <typename A>
    bool type() const
    {
      detail::cast_get g = &(detail::cast<typename mpl::remove_ref<A>::type>::get);
      return (g == g_);
    }

    template <typename A>
    typename mpl::remove_ref<A>::type& get()
    {
      return *reinterpret_cast<typename mpl::remove_ref<A>::type *> (g_(&a_[0]));
    }

    template <typename A>
    const typename mpl::remove_ref<A>::type& get() const
    {
      return *reinterpret_cast<typename mpl::remove_ref<A>::type *> (g_(&a_[0]));
    }

    void operator()() const
    {
      (*c_)(&f_[0], &a_[0]);
    }
  }; // class function
} // namespace brok

struct Demo
{
  const char* p1;
  void operator()(const char *p2)
  {
    printf("demo(\"%s\", \"%s\")\n", p1, p2);
  }
};


int main()
{
  Demo demo = {"Hello"};
  brok::function f("world", demo);
  f();
  
  f.get<const char*>() = "there!";
  f();
  
  if (f.type<Demo>())
  {
    f.get<Demo>() = demo;
    f();
  }
}

